Keyes Raspberry Pi Pico 42合1 传感器套装

![](media/b3e6400fc49642fb19f18da87d4557aa.png)

# 一、产品说明：

首先，本pico传感器教程是基于树莓派上操作的，树莓派是一台卡片电脑，它的官方系统是Raspberry Pi OS，也可以给树莓派安装其它系统，例如：ubuntu，Windows IoT。可以使用树莓派来做一个个人服务器，路由器，接上摄像头就可以做摄像头监控，摄像头识别，接上麦克风方阵和喇叭就可以做语音交互助手等。本传感器套装主要包含了我们常用的42款传感器/模块，还有对应的Raspberry Pi Pico板、Raspberry Pi Pico扩展板和杜邦线。42款传感器/模块和我们提供的Raspberry Pi Pico扩展板接口完全匹配。使用时，我们只需要将Raspberry Pi Pico板堆叠在Raspberry Pi Pico扩展板，利用自带的杜邦线将传感器/模块连接在扩展板上，简单方便。

为了让你对这个42款传感器/模块有更深入的了解，我们还基于这个42款传感器/模块做个多个学习课程。这些课程是用树莓派官方推荐的在树莓派系统上的MicroPython IDE软件平台Thonny制作的，课程中我们提供了对应的原理图、接线方法、MicroPython语言代码、实验结果和简单的代码介绍还有基本的linux操作指令等信息。通过这些课程，可以让我们对编程方法、逻辑、电子电路以及linux有了更深刻的理解。

# 产品清单：

<table>
<colgroup>
<col />
<col />
<col />
<col />
</colgroup>
<tbody>
<tr>
<td>序号</td>
<td>图片</td>
<td>规格</td>
<td>数量</td>
</tr>
<tr>
<td><ol type="1">
<li></li>
</ol></td>
<td>

![](media/c7e28ad5b3962481026bbc2134e0e90d.png)

</td>
<td>keyes 2021新款 DIY电子积木 白色LED模块 黑色环保(红色端子)</td>
<td>1</td>
</tr>
<tr>
<td><ol start="2" type="1">
<li></li>
</ol></td>
<td>

![](media/a83c862e5f56feec2d41ca36a797c0fe.png)

</td>
<td>keyes 2021新款 DIY电子积木 共阴RGB模块 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="3" type="1">
<li></li>
</ol></td>
<td>

![](media/4816fc8a161a3fcf5c1552b9669341eb.png)

</td>
<td>keyes 2021新款 DIY电子积木 交通灯模块 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="4" type="1">
<li></li>
</ol></td>
<td>

![](media/51deebe17e93ab0bfaa42693745ccf08.png)

</td>
<td>keyes 2021新款 DIY电子积木 有源蜂鸣器模块 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="5" type="1">
<li></li>
</ol></td>
<td>

![](media/b98119edb1de2788284e4ce705a55628.png)

</td>
<td>keyes 2021新款 DIY电子积木 8002b功放 喇叭模块
黑色环保(绿色端子)</td>
<td>1</td>
</tr>
<tr>
<td><ol start="6" type="1">
<li></li>
</ol></td>
<td rowspan="2">

![](media/1a90cb6e20f8bdab71de591c68c14a26.png)

</td>
<td>keyes 2021新款 DIY电子积木 单路按键模块 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="7" type="1">
<li></li>
</ol></td>
<td>按键帽 A24 黄帽(12*12*7.3)圆</td>
<td>1</td>
</tr>
<tr>
<td><ol start="8" type="1">
<li></li>
</ol></td>
<td>

![](media/90a23459b22366eb884820de548eed3b.png)

</td>
<td>keyes 2021新款 DIY电子积木 倾斜传感器 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="9" type="1">
<li></li>
</ol></td>
<td>

![](media/239131563f68fbf379e97d8384cf2d9b.png)

</td>
<td>keyes 2021新款 DIY电子积木 人体红外热释传感器
黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="10" type="1">
<li></li>
</ol></td>
<td>

![](media/efeb3f71ff4e717e1a91798b2d6d7829.png)

</td>
<td>keyes 2021新款 DIY电子积木 避障传感器 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="11" type="1">
<li></li>
</ol></td>
<td>

![](media/2f7bd7f3e7c303e7532de6a5527f839a.png)

</td>
<td>keyes 2021新款 DIY电子积木 6812 RGB模块 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="12" type="1">
<li></li>
</ol></td>
<td>

![](media/596f09feafaaf92e2f3e011871190f30.png)

</td>
<td>keyes 2021新款 DIY电子积木 NTC-MF52AT模拟温度传感器
黑色环保（绿色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="13" type="1">
<li></li>
</ol></td>
<td>

![](media/84e2dc067ddfbcf81e169a5490cc1f10.png)

</td>
<td>keyes 2021新款 DIY电子积木 光敏电阻传感器 黑色环保（绿色）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="14" type="1">
<li></li>
</ol></td>
<td>

![](media/f716748aa248722612b2a78aade2cf5f.png)

</td>
<td>keyes 2021新款 DIY电子积木 声音传感器 黑色环保（绿色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="15" type="1">
<li></li>
</ol></td>
<td>

![](media/0c95f5206cdfa7ac05275fe95fe9ee13.png)

</td>
<td>keyes 2021新款 DIY电子积木 旋转电位器传感器
黑色环保（绿色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="16" type="1">
<li></li>
</ol></td>
<td>

![](media/dc37c6b6608e8f4435d46a8ad2985f9f.png)

</td>
<td>keyes 2021新款 DIY电子积木 红外接收模块 黑色环保（蓝色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="17" type="1">
<li></li>
</ol></td>
<td>

![](media/bff5e54b01c337b7837151ce8b1e7ad9.png)

</td>
<td>keyes 2021新款 DIY电子积木 干簧管模块 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="18" type="1">
<li></li>
</ol></td>
<td>

![](media/d6fec7dc15bf3fae1e23ae935a683bfd.png)

</td>
<td>keyes 2021新款 DIY电子积木 旋转编码器模块 黑色环保（蓝色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="19" type="1">
<li></li>
</ol></td>
<td rowspan="2">

![](media/fbb1fe2e604f2ffc2a6e3be21196a38d.png)

</td>
<td>keyes 2021新款 DIY电子积木 摇杆模块 黑色环保</td>
<td>1</td>
</tr>
<tr>
<td><ol start="20" type="1">
<li></li>
</ol></td>
<td>摇杆帽3D PS2 蘑菇头环保</td>
<td>1</td>
</tr>
<tr>
<td><ol start="21" type="1">
<li></li>
</ol></td>
<td>

![](media/09e0ddbf584131e9bc34ff474d52f4d0.png)

</td>
<td>keyes 2021新款 DIY电子积木 HT16K33_8X8点阵模块
黑色环保（蓝色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="22" type="1">
<li></li>
</ol></td>
<td>

![](media/61c36ebc6656bef0257d60227515d947.png)

</td>
<td>keyes 2021新款 DIY电子积木 TM1650四位数码管模块
黑色环保（蓝色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="23" type="1">
<li></li>
</ol></td>
<td>

![](media/496a494f9a69266473d337b46b68d011.png)

</td>
<td>keyes 2021新款 DIY电子积木 薄膜压力传感器 黑色环保（绿色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="24" type="1">
<li></li>
</ol></td>
<td>

![](media/b06498ec1f073ca7a3b0613ecd6d46c9.png)

</td>
<td>keyes 2021新款 DIY电子积木 DS1307时钟传感器模块
黑色环保（蓝色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="25" type="1">
<li></li>
</ol></td>
<td>

![](media/cc99237e6c3651ddc858f2af911b1a1c.png)

</td>
<td>HC-SR04P超声波测距模块 测距传感器模块 3-5.5V宽电压（2020新款）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="26" type="1">
<li></li>
</ol></td>
<td>

![](media/826eddfc435ffbc4bc762bb0d1865ee4.png)

</td>
<td>9G 23*12.2*29mm 蓝色 90度 3V/5V兼容舵机内部电源滤波电容47UF
环保（掉电不自锁）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="27" type="1">
<li></li>
</ol></td>
<td>

![](media/b551cbf482ce6417d1ff170662ba507b.png)

</td>
<td>keyes 2021新款 DIY电子积木 电容触摸模块 黑色环保（红色）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="28" type="1">
<li></li>
</ol></td>
<td>

![](media/d9065c447b84b58ec68fb2d73b9f0843.png)

</td>
<td>keyes 2021新款 DIY电子积木 光折断模块 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="29" type="1">
<li></li>
</ol></td>
<td>

![](media/08254a6c57140fe509ab16ee75dedfd0.png)

</td>
<td>keyes 2021新款 DIY电子积木 霍尔传感器 黑色环保</td>
<td>1</td>
</tr>
<tr>
<td><ol start="30" type="1">
<li></li>
</ol></td>
<td>

![](media/4d7c8f74097bbedea2a8a2a9f55e5062.png)

</td>
<td>keyes 2021新款 DIY电子积木 火焰传感器 黑色环保（黄色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="31" type="1">
<li></li>
</ol></td>
<td>

![](media/071380d5a50e1d02dba64ed89b740ffd.png)

</td>
<td>keyes 2021新款 DIY电子积木 单路循线传感器 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="32" type="1">
<li></li>
</ol></td>
<td>

![](media/d36003a6ef55accaea6b723405a47e1e.png)

</td>
<td>keyes 2021新款 DIY电子积木 模拟气体传感器 黑色环保（黄色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="33" type="1">
<li></li>
</ol></td>
<td>

![](media/2d013e7634507fa3570235454abcd3fc.png)

</td>
<td>keyes 2021新款 DIY电子积木 XHT11温湿度传感器（兼容DHT11）
黑色环保（蓝色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="34" type="1">
<li></li>
</ol></td>
<td>

![](media/df3eb0bfba6020d90704e6ca52ba8236.png)

</td>
<td>keyes 2021新款 DIY电子积木 18B20温度传感器 黑色环保（蓝色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="35" type="1">
<li></li>
</ol></td>
<td>

![](media/6d454cc922ceff4087d9ab1e5ccf030f.png)

</td>
<td>keyes 2021新款 DIY电子积木 130电机模块 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="36" type="1">
<li></li>
</ol></td>
<td>

![](media/16f725d5da5b576a79e9299717d811d7.png)

</td>
<td>三叶软桨</td>
<td>1</td>
</tr>
<tr>
<td><ol start="37" type="1">
<li></li>
</ol></td>
<td>

![](media/88a1aef5f97a80a7e728daefea2656c5.png)

</td>
<td>keyes 2021新款 DIY电子积木 激光模块 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="38" type="1">
<li></li>
</ol></td>
<td>

![](media/9e8793031725d4816a934607009288db.png)

</td>
<td>keyes 2021新款 DIY电子积木 水滴传感器 黑色环保（绿色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="39" type="1">
<li></li>
</ol></td>
<td>

![](media/b1ea2f96abff203e8978768e94996821.png)

</td>
<td>keyes 2021新款 DIY电子积木 太阳光紫外线传感器
黑色环保（绿色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="40" type="1">
<li></li>
</ol></td>
<td>

![](media/eb57ae291b76e14c4a3d55966c00f245.png)

</td>
<td>keyes 2021新款 DIY电子积木 RFID刷卡模块 黑色环保（蓝色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="41" type="1">
<li></li>
</ol></td>
<td>

![](media/0d5c68813f56ecb4959f8ba3b2e6ec3f.png)

</td>
<td>keyes 2021新款 DIY电子积木 碰撞传感器 黑色环保（红色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="42" type="1">
<li></li>
</ol></td>
<td>

![](media/a53e6f926fa155da451a56aa2dcc2e06.png)

</td>
<td>keyes 2021新款 DIY电子积木 酒精传感器 黑色环保（黄色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="43" type="1">
<li></li>
</ol></td>
<td>

![](media/770714fabf173efb3ef34d9f84d09798.png)

</td>
<td>keyes 2021新款 DIY电子积木 LCD_128X32_DOT模块
黑色环保（蓝色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="44" type="1">
<li></li>
</ol></td>
<td>

![](media/7d8998e5df8bf7f9578a0f29e4c04b15.png)

</td>
<td>keyes 2021新款 DIY电子积木 五路AD按键模块 黑色环保（绿色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="45" type="1">
<li></li>
</ol></td>
<td>

![](media/2f62814f833dc38255036bd63c5247a5.png)

</td>
<td>keyes 2021新款 DIY电子积木 ADXL345加速度传感器模块
黑色环保（蓝色端子）</td>
<td>1</td>
</tr>
<tr>
<td><ol start="46" type="1">
<li></li>
</ol></td>
<td>

![](media/b57492c3f0fcb41347596e415122794e.png)

</td>
<td><p>树莓派 Raspberry Pi Pico 焊下排针</p>
<p>KE3036带主板</p>
<p>KE3037不带主板</p></td>
<td>1</td>
</tr>
<tr>
<td><ol start="47" type="1">
<li></li>
</ol></td>
<td>

![](media/8b6e6c604cccdf86ac5812de97d9bc9b.png)

</td>
<td>1*3直针 黄色 2.54 环保</td>
<td>1</td>
</tr>
<tr>
<td><ol start="48" type="1">
<li></li>
</ol></td>
<td>

![](media/d0d3445b137a2d70a49b32295f2b35b2.png)

</td>
<td>keyes raspberry pico IO 扩展板 黑色环保</td>
<td>1</td>
</tr>
<tr>
<td><ol start="49" type="1">
<li></li>
</ol></td>
<td>

![](media/9565387ea4d3df1816ef34e5aeaad3db.png)

</td>
<td>JMP-1 17键86*40*6.5MM 黑色 环保</td>
<td>1</td>
</tr>
<tr>
<td><ol start="50" type="1">
<li></li>
</ol></td>
<td>

![](media/edbfec59fe015bd9987e4b4d542b466d.png)

</td>
<td>AM/MK5P(micro)黑色 OD：3.5 L=1M PVC过粉</td>
<td>1</td>
</tr>
<tr>
<td><ol start="51" type="1">
<li></li>
</ol></td>
<td>

![](media/33be6266ae36f54c9e7ffd044eae9320.png)

</td>
<td>母对母20CM/40P/2.54/10股铜包铝 24号线BL 环保</td>
<td>0.1</td>
</tr>
<tr>
<td><ol start="52" type="1">
<li></li>
</ol></td>
<td>

![](media/c59ae888dc6d71e8f6e0975629a88dd4.png)

</td>
<td>XH2.54-3Pin+杜邦母单 长19.5cm (红线在中间)</td>
<td>13</td>
</tr>
<tr>
<td><ol start="53" type="1">
<li></li>
</ol></td>
<td>

![](media/9a16ac3df731a5ec4d99285136939d92.png)

</td>
<td>HX-2.54 4P 转杜邦线母单 26AWG 黑红白棕 200mm</td>
<td>6</td>
</tr>
<tr>
<td><ol start="54" type="1">
<li></li>
</ol></td>
<td>

![](media/33d050f988dd233b59ec68f3099b945b.png)

</td>
<td>HX-2.54 5P 转杜邦母单 22AWG 黑红棕白黄 200mm</td>
<td>3</td>
</tr>
<tr>
<td><ol start="55" type="1">
<li></li>
</ol></td>
<td>

![](media/ade84f2ad63242834113a981be5d5ef3.png)

</td>
<td>白卡 85.5*54*0.80MM 环保</td>
<td>1</td>
</tr>
<tr>
<td><ol start="56" type="1">
<li></li>
</ol></td>
<td>

![](media/026296d61d87b05b5167c6425e8a0bd1.png)

</td>
<td>TAG-03 41*33*403mm ABS蓝色</td>
<td>1</td>
</tr>
</tbody>
</table>

当收到这个Pico传感器套件的时候，首先看到是一个包装精美的外盒，每个配件被安全且有序的装在外盒里面的小袋子里，先来清点一下：









